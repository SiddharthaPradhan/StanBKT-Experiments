from stanbkt.models.core.base import BKTModelBase


class HierarchicalBKT:
    pass
